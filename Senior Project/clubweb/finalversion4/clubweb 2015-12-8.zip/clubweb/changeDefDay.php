<!-- 
--------------------------------------------
		   changeDefDay.php
				Yu Fu
			  2015-11-12
--------------------------------------------
This php create Change default meeting date page
which let admin to change the default date fron some day
-->

<html>
<head>
<meta content="en-us" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<link rel="stylesheet" type="text/css" href="style.css" />
<!-- forget to delete this. no this file
phpscript type="text/javascript" src="headerjs.js"></script>-->

<title>Charlottesville Warriors Circle</title>
</head>

<body>
	<?php include ('header.html'); ?>
	<?php include ('line.html'); ?>
	<?php include ('changeDay.php'); ?>
	<?php include ('line.html'); ?>
	<?php include ('footer.php'); ?>
</body>

</html>
