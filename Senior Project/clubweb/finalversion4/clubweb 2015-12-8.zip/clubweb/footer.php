<?php /* 
--------------------------------------------
			footer.html
				Yu Fu
			  2015-10-3
--------------------------------------------
*/ ?>
<div class="footer">
	<p class="footer" align="center"> Copyright &#169; 2015 - <?php echo date("Y");?></p>
</div>
<br>

	