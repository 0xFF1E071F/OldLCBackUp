<!-- 
--------------------------------------------
		     adminuser.php
				Yu Fu
			  2015-11-14
--------------------------------------------
This php create the page of 
let super admin user to modity the admin users
and delete users from out db
-->

<html>
<head>
<meta content="en-us" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<link rel="stylesheet" type="text/css" href="style.css" />
<script language="javascript" type="text/javascript" src="jquery/jquery.js"></script>


<title>Charlottesville Warriors Circle</title>
</head>

<body>
	<?php include ('header.html'); ?>
	<?php include ('line.html'); ?>

	<?php include ('setupusers.php'); ?>

	<?php include ('line.html'); ?>
	<?php include ('footer.php'); ?>
</body>

</html>
